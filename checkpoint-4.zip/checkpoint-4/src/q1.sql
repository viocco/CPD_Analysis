-- For every officer, return the number of trr's that they should have created

SELECT *
FROM
(SELECT CASE WHEN tem.officer_id IS NULL THEN total.officer_id ELSE tem.officer_id END AS officer_id,
       CASE WHEN theoretical_trr_count IS NULL THEN 0 ELSE theoretical_trr_count END AS new_theoretical_trr_count,
       CASE WHEN trr_count IS NULL THEN 0 ELSE trr_count END AS new_trr_count,
       CASE WHEN trr_count IS NULL THEN theoretical_trr_count
                           WHEN theoretical_trr_count IS NOT NULL AND theoretical_trr_count - trr_count > 0 THEN theoretical_trr_count - trr_count
                           ELSE NULL END AS num_uncounted_aggressions
FROM (SELECT tmp.officer_id, count(*) as trr_count
      FROM (SELECT crid, DOA.id, DOA.officer_id
            FROM data_allegation DA,data_officerallegation DOA, data_allegationcategory DAC
            WHERE DA.crid = DOA.allegation_id AND DOA.allegation_category_id = DAC.id AND (DAC.category ILIKE '%Force%') AND DATE(DA.incident_date) >= '01/01/2004' AND DATE(DA.incident_date) < '01/01/2016') as tmp, trr_trr
      WHERE tmp.crid = trr_trr.crid
      GROUP BY tmp.officer_id) tem
FULL OUTER JOIN (SELECT DOA.officer_id, count(*) as theoretical_trr_count
      FROM data_allegation DA,data_officerallegation DOA, data_allegationcategory DAC
      WHERE DA.crid = DOA.allegation_id AND DOA.allegation_category_id = DAC.id AND (DAC.category ILIKE '%Force%') AND DATE(DA.incident_date) >= '01/01/2004' AND DATE(DA.incident_date) < '01/01/2016'
      GROUP BY DOA.officer_id) total
ON tem.officer_id = total.officer_id
ORDER BY num_uncounted_aggressions DESC) as tr
WHERE num_uncounted_aggressions IS NOT NULL

SELECT *
FROM
(SELECT CASE WHEN tem.officer_id IS NULL THEN total.officer_id ELSE tem.officer_id END AS officer_id,
       CASE WHEN theoretical_trr_count IS NULL THEN 0 ELSE theoretical_trr_count END AS new_theoretical_trr_count,
       CASE WHEN trr_count IS NULL THEN 0 ELSE trr_count END AS new_trr_count,
       CASE WHEN trr_count IS NULL THEN 100.0
                         WHEN theoretical_trr_count IS NOT NULL AND (theoretical_trr_count - trr_count)*100.0/theoretical_trr_count > 0 THEN ROUND((theoretical_trr_count - trr_count)*100.0/theoretical_trr_count,3)
                         ELSE NULL END AS num_uncounted_aggressions
FROM (SELECT tmp.officer_id, count(*) as trr_count
      FROM (SELECT crid, DOA.id, DOA.officer_id
            FROM data_allegation DA,data_officerallegation DOA, data_allegationcategory DAC
            WHERE DA.crid = DOA.allegation_id AND DOA.allegation_category_id = DAC.id AND (DAC.category ILIKE '%Force%') AND DATE(DA.incident_date) >= '01/01/2004' AND DATE(DA.incident_date) < '01/01/2016') as tmp, trr_trr
      WHERE tmp.crid = trr_trr.crid
      GROUP BY tmp.officer_id) tem
FULL OUTER JOIN (SELECT DOA.officer_id, count(*) as theoretical_trr_count
      FROM data_allegation DA,data_officerallegation DOA, data_allegationcategory DAC
      WHERE DA.crid = DOA.allegation_id AND DOA.allegation_category_id = DAC.id AND (DAC.category ILIKE '%Force%') AND DATE(DA.incident_date) >= '01/01/2004' AND DATE(DA.incident_date) < '01/01/2016'
      GROUP BY DOA.officer_id) total
ON tem.officer_id = total.officer_id
ORDER BY num_uncounted_aggressions DESC) as tr
WHERE num_uncounted_aggressions IS NOT NULL
