
# Checkpoint #3

In this checkpoint, we ran graphical analysis on the data.
In order to access our code, please see https://colab.research.google.com/drive/1gBGkEgY1-CMV2SGiVr5PE5Kff7mwFAf5?authuser=1#scrollTo=7u1qh4M6rA8T 
and run the entire notebook. The questions we answered are as follows:

    1) Is there a correlation between how well an officer follows TRR policy and
       how likely their partners are to follow TRR policy?
    2) Is there a correlation between the number of missing recommended 
       findings/outcomes an officer receives and the number their partners receive?

For question 2, there is an interactive graphic that can be accessed in src/network.html. The src/*.sql files are the sql queries ran in Google Colab.