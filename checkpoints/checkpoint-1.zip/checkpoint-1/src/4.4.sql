-- Question 4:  Is there a correlation between the race of the victim and the rate at which the recommended finding and outcome are finalized?  --
--  1) When grouped by the race of the victim, what is the distribution of recommended findings as counts and percentages of the
--     race's total allegations?
--  2) When grouped by the race of the victim, what is the distribution of final findings as counts and percentages of the race's
--     total allegations?
--  3) When grouped by the race of the victim, what is the distribution of recommended outcomes as counts and percentages of the
--     race's total allegations?
--  4) When grouped by the race of the victim, what is the distribution of final outcomes as counts and percentages of the race's
--     total allegations?
--  5) When grouped by race of victim, what percent of complaints in each race have a more/less severe recommended finding than
--     final finding (as a percent of? What percent of complaints in each allegation category have recommended findings or final findings that are null/unknown?
--  6) When grouped by race of victim, what percent of complaints in each race have a more/less severe recommended outcome than
--     final outcome?  What percent of complaints in each allegation category have recommended outcomes or final outcomes are
--     null/unknown?

-- Creating a temporary table with the counts of all the suspended summed together --
DROP TABLE IF EXISTS cleaned_DOA_fin;
CREATE TEMPORARY TABLE cleaned_DOA_fin AS (SELECT * FROM data_officerallegation);
UPDATE cleaned_DOA_fin SET final_outcome='Suspended' WHERE final_outcome ILIKE '%Suspen%';
SELECT tem.race                   as race,
       tem.final_outcome           as final_outcome,
       ROUND((100.0 * tem.N) / total.N,2) as Pct,
       tem.N                      as count
FROM ( SELECT race, final_outcome, count(*) as N
       FROM data_victim as DV, data_allegation as DA, cleaned_DOA_fin as DOA
       WHERE DV.allegation_id = DA.crid AND DA.crid = DOA.allegation_id
       GROUP BY DV.race, DOA.final_outcome
     ) tem
JOIN ( SELECT race , count(*) as N
       FROM data_victim as DV, data_allegation as DA, cleaned_DOA_fin as DOA
       WHERE DV.allegation_id = DA.crid AND DA.crid = DOA.allegation_id
       GROUP BY race
     ) total ON tem.race = total.race
ORDER BY tem.final_outcome, Pct DESC;

DROP TABLE IF EXISTS cleaned_DOA_fin;
CREATE TEMPORARY TABLE cleaned_DOA_fin AS (SELECT * FROM data_officerallegation);
UPDATE cleaned_DOA_fin SET final_outcome='Suspended' WHERE final_outcome ILIKE '%Suspen%';
SELECT tem.officer_id                   as officer_id,
       ROUND((100.0 * tem.N) / total.N,2) as Pct,
       tem.N                      as null_count,
       total.N                    as total_count
FROM ( SELECT officer_id, count(*) as N
       FROM data_allegation as DA, data_officerallegation as DOA
       WHERE DA.crid = DOA.allegation_id AND DOA.recc_finding ILIKE ''
       GROUP BY DOA.officer_id, DOA.final_outcome
     ) tem
JOIN ( SELECT officer_id, count(*) as N
       FROM data_allegation as DA, data_officerallegation as DOA
       WHERE  DA.crid = DOA.allegation_id
       GROUP BY DOA.officer_id
     ) total ON tem.officer_id = total.officer_id
ORDER BY Pct DESC;

SELECT * FROM data_officerallegation