-- Question 2: What are the frequencies of mismatches in TRR and complaint report filings? --
--  2.1) What are the categories for which an officer filed a TRR? What are the counts and percentages (as a percentage of
--       total officers allegations with a matching TRR) for these TRR categories?
--  2.2) How many instances are there when an allegation for force/excessive force is filed by a civilian and there is a
--       Tactical Response Report (TRR) filed by the officer? What is this as a percentage of allegations of force/excessive force?

SELECT count(*), ROUND(count(*)*100.0/(SELECT count(*) FROM data_allegation DA,data_officerallegation DOA, data_allegationcategory DAC
                                        WHERE DA.crid = DOA.allegation_id AND DOA.allegation_category_id = DAC.id AND (DAC.category ILIKE '%Force%') AND DATE(DA.incident_date) >= '01/01/2004' AND DATE(DA.incident_date) < '01/01/2016'),2) AS percent_w_trr
FROM (SELECT *
      FROM data_allegation DA,data_officerallegation DOA, data_allegationcategory DAC
      WHERE DA.crid = DOA.allegation_id AND DOA.allegation_category_id = DAC.id AND (DAC.category ILIKE '%Force%') AND DATE(DA.incident_date) >= '01/01/2004' AND DATE(DA.incident_date) < '01/01/2016') as tmp, trr_trr
WHERE tmp.crid = trr_trr.crid;