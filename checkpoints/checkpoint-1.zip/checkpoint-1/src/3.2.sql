-- Question 3: Are certain groups of categories more likely to result in a more/less severe final findings or outcome than recommended for officers? --
--  1) When grouped by allegation category, what percent of complaints in each allegation category have a more/less severe recommended finding
--     than final finding? What percent of complaints in each allegation category have recommended findings or final findings that are null?
--  2) When grouped by allegation category, what percent of complaints in each allegation category have a more/less severe recommended outcome
--     than final outcome?  What percent of complaints in each allegation category have recommended outcomes or final outcomes are null?

-- // Create a temporary table
DROP TABLE IF EXISTS tmp;
CREATE TEMPORARY TABLE tmp (outcome varchar(255), severity int, PRIMARY KEY(outcome));
INSERT INTO tmp(outcome,severity) VALUES ('Resigned', 61),
                                         ('Resigned -Not Served', 61),
                                         ('Separated Other Case', 61),
                                         ('No Action Taken', 60),
                                         ('Penalty Not Served', 59),
                                         ('Reinstated By Court Action', 58),
                                         ('Reinstated By Police Board', 57),
                                         ('Sustained-No Penalty', 56),
                                         ('Violation Noted', 55),
                                         ('Reprimand', 54),
                                         ('Separation', 53),
                                         ('Suspension', 52),
                                         ('1 Day Suspension', 51),
                                         ('2 Day Suspension', 50),
                                         ('3 Day Suspension', 49),
                                         ('4 Day Suspension', 48),
                                         ('5 Day Suspension', 47),
                                         ('6 Day Suspension', 46),
                                         ('7 Day Suspension', 45),
                                         ('8 Day Suspension', 44),
                                         ('9 Day Suspension', 43),
                                         ('10 Day Suspension', 42),
                                         ('11 Day Suspension', 41),
                                         ('12 Day Suspension', 40),
                                         ('13 Day Suspension', 39),
                                         ('14 Day Suspension', 38),
                                         ('15 Day Suspension', 37),
                                         ('16 Day Suspension', 36),
                                         ('17 Day Suspension', 35),
                                         ('18 Day Suspension', 34),
                                         ('20 Day Suspension', 33),
                                         ('21 Day Suspension', 32),
                                         ('22 Day Suspension', 31),
                                         ('23 Day Suspension', 30),
                                         ('24 Day Suspension', 29),
                                         ('25 Day Suspension', 28),
                                         ('27 Day Suspension', 27),
                                         ('28 Day Suspension', 26),
                                         ('29 Day Suspension', 25),
                                         ('30 Day Suspension', 23),
                                         ('Suspended Over 30 Days', 23),
                                         ('31 Day Suspension', 22),
                                         ('35 Day Suspension', 21),
                                         ('40 Day Suspension', 20),
                                         ('45 Day Suspension', 19),
                                         ('56 Day Suspension', 18),
                                         ('60 Day Suspension', 17),
                                         ('75 Day Suspension', 16),
                                         ('90 Day Suspension', 15),
                                         ('99 Day Suspension', 14),
                                         ('Suspended For 120 Days', 12),
                                         ('120 Day Suspension', 12),
                                         ('150 Day Suspension', 11),
                                         ('Suspended For 180 Days', 10),
                                         ('180 Day Suspension', 9),
                                         ('270 Day Suspension', 8),
                                         ('300 Day Suspension', 7),
                                         ('326 Day Suspension', 6),
                                         ('365 Day Suspension', 5),
                                         ('540 Day Suspension', 4),
                                         ('900 Day Suspension', 3),
                                         ('Suspended Indefinitely', 2),
                                         ('Administrative Termination', 1),
                                         ('Unknown', NULL);

-- ORDER BY PERCENT EQUAL --
WITH count_table AS (SELECT category, tmp5.recc_severity, tmp5.final_severity
                     FROM (SELECT category, allegation_category_id, tmp4.recc_severity, tmp4.final_severity, DAC.id
                          FROM data_allegationcategory as DAC
                          LEFT JOIN (SELECT tmp2.allegation_category_id, tmp2.officer_id, tmp2.allegation_id, tmp2.severity as recc_severity, tmp3.severity as final_severity
                                                                  FROM (SELECT *
                                                                        FROM data_officerallegation as DOA
                                                                        JOIN tmp ON DOA.recc_outcome ILIKE tmp.outcome) as tmp2,
                                                                        (SELECT *
                                                                         FROM data_officerallegation as DOA
                                                                         JOIN tmp ON DOA.final_outcome ILIKE tmp.outcome) as tmp3
                                                                  WHERE tmp2.id = tmp3.id) AS tmp4
                    ON tmp4.allegation_category_id = DAC.id) as tmp5),

    less_severe AS (SELECT tmp7.category, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS less_severe_count
                   FROM (SELECT DISTINCT category FROM data_allegationcategory) as tmp7
                   LEFT JOIN (SELECT category, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity > count_table.final_severity
                   GROUP BY category) as tmp6 ON tmp6.category = tmp7.category),
    more_severe AS (SELECT tmp7.category, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS more_severe_count
                   FROM (SELECT DISTINCT category FROM data_allegationcategory) as tmp7
                   LEFT JOIN (SELECT category, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity < count_table.final_severity
                   GROUP BY category) as tmp6 ON tmp6.category = tmp7.category),
    null_final AS (SELECT tmp7.category, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS null_final_count
                   FROM (SELECT DISTINCT category FROM data_allegationcategory) as tmp7
                   LEFT JOIN (SELECT category, count(*)
                   FROM count_table
                   WHERE count_table.final_severity IS NULL AND count_table.recc_severity IS NOT NULL
                   GROUP BY category) as tmp6 ON tmp6.category = tmp7.category),
    null_recc AS (SELECT tmp7.category, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS null_recc_count
                   FROM (SELECT DISTINCT category FROM data_allegationcategory) as tmp7
                   LEFT JOIN (SELECT category, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity IS NULL AND count_table.final_severity IS NOT NULL
                   GROUP BY category) as tmp6 ON tmp6.category = tmp7.category),
    null_both AS (SELECT tmp7.category, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS null_both_count
                   FROM (SELECT DISTINCT category FROM data_allegationcategory) as tmp7
                   LEFT JOIN (SELECT category, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity IS NULL AND count_table.final_severity IS NULL
                   GROUP BY category) as tmp6 ON tmp6.category = tmp7.category),
     equal AS (SELECT tmp7.category, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS equal_count
                   FROM (SELECT DISTINCT category FROM data_allegationcategory) as tmp7
                   LEFT JOIN (SELECT category, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity = count_table.final_severity
                   GROUP BY category) as tmp6 ON tmp6.category = tmp7.category),
    sum AS (SELECT less_severe.category, less_severe_count+more_severe_count+null_final_count+null_recc_count+null_both_count+equal_count as cum_sum
            FROM less_severe,more_severe,null_recc, null_final,null_both,equal
            WHERE less_severe.category = more_severe.category AND less_severe.category = null_recc.category AND less_severe.category = null_final.category
            AND less_severe.category = null_both.category AND less_severe.category = equal.category)
SELECT less_severe.category, ROUND(100.0*equal_count/cum_sum,2) as pct_equal, ROUND(100.0*less_severe_count/cum_sum,2) as pct_less_severe, ROUND(100.0*more_severe_count/cum_sum,2) as pct_more_severe, ROUND(100.0*null_final_count/cum_sum,2) as pct_null_final, ROUND(100.0*null_recc_count/cum_sum,2) as pct_null_rec, ROUND(100.0*null_both_count/cum_sum,2) as pct_null_both, cum_sum as count
FROM less_severe,more_severe,null_recc, null_final,null_both, equal, sum
WHERE less_severe.category = more_severe.category AND less_severe.category = null_recc.category AND less_severe.category = null_final.category
    AND less_severe.category = null_both.category AND sum.category = less_severe.category AND less_severe.category = equal.category
ORDER BY pct_equal DESC;

-- ORDER BY PERCENT LESS SEVERE --
WITH count_table AS (SELECT category, tmp5.recc_severity, tmp5.final_severity
                     FROM (SELECT category, allegation_category_id, tmp4.recc_severity, tmp4.final_severity, DAC.id
                          FROM data_allegationcategory as DAC
                          LEFT JOIN (SELECT tmp2.allegation_category_id, tmp2.officer_id, tmp2.allegation_id, tmp2.severity as recc_severity, tmp3.severity as final_severity
                                                                  FROM (SELECT *
                                                                        FROM data_officerallegation as DOA
                                                                        JOIN tmp ON DOA.recc_outcome ILIKE tmp.outcome) as tmp2,
                                                                        (SELECT *
                                                                         FROM data_officerallegation as DOA
                                                                         JOIN tmp ON DOA.final_outcome ILIKE tmp.outcome) as tmp3
                                                                  WHERE tmp2.id = tmp3.id) AS tmp4
                    ON tmp4.allegation_category_id = DAC.id) as tmp5),

    less_severe AS (SELECT tmp7.category, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS less_severe_count
                   FROM (SELECT DISTINCT category FROM data_allegationcategory) as tmp7
                   LEFT JOIN (SELECT category, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity > count_table.final_severity
                   GROUP BY category) as tmp6 ON tmp6.category = tmp7.category),
    more_severe AS (SELECT tmp7.category, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS more_severe_count
                   FROM (SELECT DISTINCT category FROM data_allegationcategory) as tmp7
                   LEFT JOIN (SELECT category, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity < count_table.final_severity
                   GROUP BY category) as tmp6 ON tmp6.category = tmp7.category),
    null_final AS (SELECT tmp7.category, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS null_final_count
                   FROM (SELECT DISTINCT category FROM data_allegationcategory) as tmp7
                   LEFT JOIN (SELECT category, count(*)
                   FROM count_table
                   WHERE count_table.final_severity IS NULL AND count_table.recc_severity IS NOT NULL
                   GROUP BY category) as tmp6 ON tmp6.category = tmp7.category),
    null_recc AS (SELECT tmp7.category, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS null_recc_count
                   FROM (SELECT DISTINCT category FROM data_allegationcategory) as tmp7
                   LEFT JOIN (SELECT category, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity IS NULL AND count_table.final_severity IS NOT NULL
                   GROUP BY category) as tmp6 ON tmp6.category = tmp7.category),
    null_both AS (SELECT tmp7.category, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS null_both_count
                   FROM (SELECT DISTINCT category FROM data_allegationcategory) as tmp7
                   LEFT JOIN (SELECT category, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity IS NULL AND count_table.final_severity IS NULL
                   GROUP BY category) as tmp6 ON tmp6.category = tmp7.category),
     equal AS (SELECT tmp7.category, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS equal_count
                   FROM (SELECT DISTINCT category FROM data_allegationcategory) as tmp7
                   LEFT JOIN (SELECT category, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity = count_table.final_severity
                   GROUP BY category) as tmp6 ON tmp6.category = tmp7.category),
    sum AS (SELECT less_severe.category, less_severe_count+more_severe_count+null_final_count+null_recc_count+null_both_count+equal_count as cum_sum
            FROM less_severe,more_severe,null_recc, null_final,null_both,equal
            WHERE less_severe.category = more_severe.category AND less_severe.category = null_recc.category AND less_severe.category = null_final.category
            AND less_severe.category = null_both.category AND less_severe.category = equal.category)
SELECT less_severe.category, ROUND(100.0*less_severe_count/cum_sum,2) as pct_less_severe, ROUND(100.0*equal_count/cum_sum,2) as pct_equal, ROUND(100.0*more_severe_count/cum_sum,2) as pct_more_severe, ROUND(100.0*null_final_count/cum_sum,2) as pct_null_final, ROUND(100.0*null_recc_count/cum_sum,2) as pct_null_rec, ROUND(100.0*null_both_count/cum_sum,2) as pct_null_both, cum_sum as count
FROM less_severe,more_severe,null_recc, null_final,null_both, equal, sum
WHERE less_severe.category = more_severe.category AND less_severe.category = null_recc.category AND less_severe.category = null_final.category
    AND less_severe.category = null_both.category AND sum.category = less_severe.category AND less_severe.category = equal.category
ORDER BY pct_less_severe DESC;

-- ORDER BY PERCENT MORE SEVERE --
WITH count_table AS (SELECT category, tmp5.recc_severity, tmp5.final_severity
                     FROM (SELECT category, allegation_category_id, tmp4.recc_severity, tmp4.final_severity, DAC.id
                          FROM data_allegationcategory as DAC
                          LEFT JOIN (SELECT tmp2.allegation_category_id, tmp2.officer_id, tmp2.allegation_id, tmp2.severity as recc_severity, tmp3.severity as final_severity
                                                                  FROM (SELECT *
                                                                        FROM data_officerallegation as DOA
                                                                        JOIN tmp ON DOA.recc_outcome ILIKE tmp.outcome) as tmp2,
                                                                        (SELECT *
                                                                         FROM data_officerallegation as DOA
                                                                         JOIN tmp ON DOA.final_outcome ILIKE tmp.outcome) as tmp3
                                                                  WHERE tmp2.id = tmp3.id) AS tmp4
                    ON tmp4.allegation_category_id = DAC.id) as tmp5),

    less_severe AS (SELECT tmp7.category, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS less_severe_count
                   FROM (SELECT DISTINCT category FROM data_allegationcategory) as tmp7
                   LEFT JOIN (SELECT category, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity > count_table.final_severity
                   GROUP BY category) as tmp6 ON tmp6.category = tmp7.category),
    more_severe AS (SELECT tmp7.category, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS more_severe_count
                   FROM (SELECT DISTINCT category FROM data_allegationcategory) as tmp7
                   LEFT JOIN (SELECT category, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity < count_table.final_severity
                   GROUP BY category) as tmp6 ON tmp6.category = tmp7.category),
    null_final AS (SELECT tmp7.category, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS null_final_count
                   FROM (SELECT DISTINCT category FROM data_allegationcategory) as tmp7
                   LEFT JOIN (SELECT category, count(*)
                   FROM count_table
                   WHERE count_table.final_severity IS NULL AND count_table.recc_severity IS NOT NULL
                   GROUP BY category) as tmp6 ON tmp6.category = tmp7.category),
    null_recc AS (SELECT tmp7.category, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS null_recc_count
                   FROM (SELECT DISTINCT category FROM data_allegationcategory) as tmp7
                   LEFT JOIN (SELECT category, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity IS NULL AND count_table.final_severity IS NOT NULL
                   GROUP BY category) as tmp6 ON tmp6.category = tmp7.category),
    null_both AS (SELECT tmp7.category, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS null_both_count
                   FROM (SELECT DISTINCT category FROM data_allegationcategory) as tmp7
                   LEFT JOIN (SELECT category, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity IS NULL AND count_table.final_severity IS NULL
                   GROUP BY category) as tmp6 ON tmp6.category = tmp7.category),
     equal AS (SELECT tmp7.category, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS equal_count
                   FROM (SELECT DISTINCT category FROM data_allegationcategory) as tmp7
                   LEFT JOIN (SELECT category, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity = count_table.final_severity
                   GROUP BY category) as tmp6 ON tmp6.category = tmp7.category),
    sum AS (SELECT less_severe.category, less_severe_count+more_severe_count+null_final_count+null_recc_count+null_both_count+equal_count as cum_sum
            FROM less_severe,more_severe,null_recc, null_final,null_both,equal
            WHERE less_severe.category = more_severe.category AND less_severe.category = null_recc.category AND less_severe.category = null_final.category
            AND less_severe.category = null_both.category AND less_severe.category = equal.category)
SELECT less_severe.category, ROUND(100.0*more_severe_count/cum_sum,2) as pct_more_severe, ROUND(100.0*equal_count/cum_sum,2) as pct_equal, ROUND(100.0*less_severe_count/cum_sum,2) as pct_less_severe, ROUND(100.0*null_final_count/cum_sum,2) as pct_null_final, ROUND(100.0*null_recc_count/cum_sum,2) as pct_null_rec, ROUND(100.0*null_both_count/cum_sum,2) as pct_null_both, cum_sum as count
FROM less_severe,more_severe,null_recc, null_final,null_both, equal, sum
WHERE less_severe.category = more_severe.category AND less_severe.category = null_recc.category AND less_severe.category = null_final.category
    AND less_severe.category = null_both.category AND sum.category = less_severe.category AND less_severe.category = equal.category
ORDER BY pct_more_severe DESC;

-- ORDER BY PERCENT OF DATA WITH ONLY RECC NULL --
WITH count_table AS (SELECT category, tmp5.recc_severity, tmp5.final_severity
                     FROM (SELECT category, allegation_category_id, tmp4.recc_severity, tmp4.final_severity, DAC.id
                          FROM data_allegationcategory as DAC
                          LEFT JOIN (SELECT tmp2.allegation_category_id, tmp2.officer_id, tmp2.allegation_id, tmp2.severity as recc_severity, tmp3.severity as final_severity
                                                                  FROM (SELECT *
                                                                        FROM data_officerallegation as DOA
                                                                        JOIN tmp ON DOA.recc_outcome ILIKE tmp.outcome) as tmp2,
                                                                        (SELECT *
                                                                         FROM data_officerallegation as DOA
                                                                         JOIN tmp ON DOA.final_outcome ILIKE tmp.outcome) as tmp3
                                                                  WHERE tmp2.id = tmp3.id) AS tmp4
                    ON tmp4.allegation_category_id = DAC.id) as tmp5),

    less_severe AS (SELECT tmp7.category, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS less_severe_count
                   FROM (SELECT DISTINCT category FROM data_allegationcategory) as tmp7
                   LEFT JOIN (SELECT category, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity > count_table.final_severity
                   GROUP BY category) as tmp6 ON tmp6.category = tmp7.category),
    more_severe AS (SELECT tmp7.category, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS more_severe_count
                   FROM (SELECT DISTINCT category FROM data_allegationcategory) as tmp7
                   LEFT JOIN (SELECT category, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity < count_table.final_severity
                   GROUP BY category) as tmp6 ON tmp6.category = tmp7.category),
    null_final AS (SELECT tmp7.category, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS null_final_count
                   FROM (SELECT DISTINCT category FROM data_allegationcategory) as tmp7
                   LEFT JOIN (SELECT category, count(*)
                   FROM count_table
                   WHERE count_table.final_severity IS NULL AND count_table.recc_severity IS NOT NULL
                   GROUP BY category) as tmp6 ON tmp6.category = tmp7.category),
    null_recc AS (SELECT tmp7.category, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS null_recc_count
                   FROM (SELECT DISTINCT category FROM data_allegationcategory) as tmp7
                   LEFT JOIN (SELECT category, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity IS NULL AND count_table.final_severity IS NOT NULL
                   GROUP BY category) as tmp6 ON tmp6.category = tmp7.category),
    null_both AS (SELECT tmp7.category, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS null_both_count
                   FROM (SELECT DISTINCT category FROM data_allegationcategory) as tmp7
                   LEFT JOIN (SELECT category, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity IS NULL AND count_table.final_severity IS NULL
                   GROUP BY category) as tmp6 ON tmp6.category = tmp7.category),
     equal AS (SELECT tmp7.category, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS equal_count
                   FROM (SELECT DISTINCT category FROM data_allegationcategory) as tmp7
                   LEFT JOIN (SELECT category, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity = count_table.final_severity
                   GROUP BY category) as tmp6 ON tmp6.category = tmp7.category),
    sum AS (SELECT less_severe.category, less_severe_count+more_severe_count+null_final_count+null_recc_count+null_both_count+equal_count as cum_sum
            FROM less_severe,more_severe,null_recc, null_final,null_both,equal
            WHERE less_severe.category = more_severe.category AND less_severe.category = null_recc.category AND less_severe.category = null_final.category
            AND less_severe.category = null_both.category AND less_severe.category = equal.category)
SELECT less_severe.category, ROUND(100.0*null_recc_count/cum_sum,2) as pct_null_rec, ROUND(100.0*equal_count/cum_sum,2) as pct_equal, ROUND(100.0*less_severe_count/cum_sum,2) as pct_less_severe, ROUND(100.0*more_severe_count/cum_sum,2) as pct_more_severe, ROUND(100.0*null_final_count/cum_sum,2) as pct_null_final, ROUND(100.0*null_both_count/cum_sum,2) as pct_null_both, cum_sum as count
FROM less_severe,more_severe,null_recc, null_final,null_both, equal, sum
WHERE less_severe.category = more_severe.category AND less_severe.category = null_recc.category AND less_severe.category = null_final.category
    AND less_severe.category = null_both.category AND sum.category = less_severe.category AND less_severe.category = equal.category
ORDER BY pct_null_rec DESC;

-- ORDER BY PERCENT OF DATA WITH ONLY FINAL NULL --
WITH count_table AS (SELECT category, tmp5.recc_severity, tmp5.final_severity
                     FROM (SELECT category, allegation_category_id, tmp4.recc_severity, tmp4.final_severity, DAC.id
                          FROM data_allegationcategory as DAC
                          LEFT JOIN (SELECT tmp2.allegation_category_id, tmp2.officer_id, tmp2.allegation_id, tmp2.severity as recc_severity, tmp3.severity as final_severity
                                                                  FROM (SELECT *
                                                                        FROM data_officerallegation as DOA
                                                                        JOIN tmp ON DOA.recc_outcome ILIKE tmp.outcome) as tmp2,
                                                                        (SELECT *
                                                                         FROM data_officerallegation as DOA
                                                                         JOIN tmp ON DOA.final_outcome ILIKE tmp.outcome) as tmp3
                                                                  WHERE tmp2.id = tmp3.id) AS tmp4
                    ON tmp4.allegation_category_id = DAC.id) as tmp5),

    less_severe AS (SELECT tmp7.category, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS less_severe_count
                   FROM (SELECT DISTINCT category FROM data_allegationcategory) as tmp7
                   LEFT JOIN (SELECT category, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity > count_table.final_severity
                   GROUP BY category) as tmp6 ON tmp6.category = tmp7.category),
    more_severe AS (SELECT tmp7.category, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS more_severe_count
                   FROM (SELECT DISTINCT category FROM data_allegationcategory) as tmp7
                   LEFT JOIN (SELECT category, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity < count_table.final_severity
                   GROUP BY category) as tmp6 ON tmp6.category = tmp7.category),
    null_final AS (SELECT tmp7.category, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS null_final_count
                   FROM (SELECT DISTINCT category FROM data_allegationcategory) as tmp7
                   LEFT JOIN (SELECT category, count(*)
                   FROM count_table
                   WHERE count_table.final_severity IS NULL AND count_table.recc_severity IS NOT NULL
                   GROUP BY category) as tmp6 ON tmp6.category = tmp7.category),
    null_recc AS (SELECT tmp7.category, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS null_recc_count
                   FROM (SELECT DISTINCT category FROM data_allegationcategory) as tmp7
                   LEFT JOIN (SELECT category, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity IS NULL AND count_table.final_severity IS NOT NULL
                   GROUP BY category) as tmp6 ON tmp6.category = tmp7.category),
    null_both AS (SELECT tmp7.category, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS null_both_count
                   FROM (SELECT DISTINCT category FROM data_allegationcategory) as tmp7
                   LEFT JOIN (SELECT category, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity IS NULL AND count_table.final_severity IS NULL
                   GROUP BY category) as tmp6 ON tmp6.category = tmp7.category),
     equal AS (SELECT tmp7.category, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS equal_count
                   FROM (SELECT DISTINCT category FROM data_allegationcategory) as tmp7
                   LEFT JOIN (SELECT category, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity = count_table.final_severity
                   GROUP BY category) as tmp6 ON tmp6.category = tmp7.category),
    sum AS (SELECT less_severe.category, less_severe_count+more_severe_count+null_final_count+null_recc_count+null_both_count+equal_count as cum_sum
            FROM less_severe,more_severe,null_recc, null_final,null_both,equal
            WHERE less_severe.category = more_severe.category AND less_severe.category = null_recc.category AND less_severe.category = null_final.category
            AND less_severe.category = null_both.category AND less_severe.category = equal.category)
SELECT less_severe.category, ROUND(100.0*null_final_count/cum_sum,2) as pct_null_final, ROUND(100.0*equal_count/cum_sum,2) as pct_equal, ROUND(100.0*less_severe_count/cum_sum,2) as pct_less_severe, ROUND(100.0*more_severe_count/cum_sum,2) as pct_more_severe, ROUND(100.0*null_recc_count/cum_sum,2) as pct_null_rec, ROUND(100.0*null_both_count/cum_sum,2) as pct_null_both, cum_sum as count
FROM less_severe,more_severe,null_recc, null_final,null_both, equal, sum
WHERE less_severe.category = more_severe.category AND less_severe.category = null_recc.category AND less_severe.category = null_final.category
    AND less_severe.category = null_both.category AND sum.category = less_severe.category AND less_severe.category = equal.category
ORDER BY pct_null_final DESC;

-- ORDER BY PERCENT OF DATA WITH BOTH NULL --
WITH count_table AS (SELECT category, tmp5.recc_severity, tmp5.final_severity
                     FROM (SELECT category, allegation_category_id, tmp4.recc_severity, tmp4.final_severity, DAC.id
                          FROM data_allegationcategory as DAC
                          LEFT JOIN (SELECT tmp2.allegation_category_id, tmp2.officer_id, tmp2.allegation_id, tmp2.severity as recc_severity, tmp3.severity as final_severity
                                                                  FROM (SELECT *
                                                                        FROM data_officerallegation as DOA
                                                                        JOIN tmp ON DOA.recc_outcome ILIKE tmp.outcome) as tmp2,
                                                                        (SELECT *
                                                                         FROM data_officerallegation as DOA
                                                                         JOIN tmp ON DOA.final_outcome ILIKE tmp.outcome) as tmp3
                                                                  WHERE tmp2.id = tmp3.id) AS tmp4
                    ON tmp4.allegation_category_id = DAC.id) as tmp5),

    less_severe AS (SELECT tmp7.category, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS less_severe_count
                   FROM (SELECT DISTINCT category FROM data_allegationcategory) as tmp7
                   LEFT JOIN (SELECT category, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity > count_table.final_severity
                   GROUP BY category) as tmp6 ON tmp6.category = tmp7.category),
    more_severe AS (SELECT tmp7.category, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS more_severe_count
                   FROM (SELECT DISTINCT category FROM data_allegationcategory) as tmp7
                   LEFT JOIN (SELECT category, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity < count_table.final_severity
                   GROUP BY category) as tmp6 ON tmp6.category = tmp7.category),
    null_final AS (SELECT tmp7.category, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS null_final_count
                   FROM (SELECT DISTINCT category FROM data_allegationcategory) as tmp7
                   LEFT JOIN (SELECT category, count(*)
                   FROM count_table
                   WHERE count_table.final_severity IS NULL AND count_table.recc_severity IS NOT NULL
                   GROUP BY category) as tmp6 ON tmp6.category = tmp7.category),
    null_recc AS (SELECT tmp7.category, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS null_recc_count
                   FROM (SELECT DISTINCT category FROM data_allegationcategory) as tmp7
                   LEFT JOIN (SELECT category, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity IS NULL AND count_table.final_severity IS NOT NULL
                   GROUP BY category) as tmp6 ON tmp6.category = tmp7.category),
    null_both AS (SELECT tmp7.category, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS null_both_count
                   FROM (SELECT DISTINCT category FROM data_allegationcategory) as tmp7
                   LEFT JOIN (SELECT category, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity IS NULL AND count_table.final_severity IS NULL
                   GROUP BY category) as tmp6 ON tmp6.category = tmp7.category),
     equal AS (SELECT tmp7.category, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS equal_count
                   FROM (SELECT DISTINCT category FROM data_allegationcategory) as tmp7
                   LEFT JOIN (SELECT category, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity = count_table.final_severity
                   GROUP BY category) as tmp6 ON tmp6.category = tmp7.category),
    sum AS (SELECT less_severe.category, less_severe_count+more_severe_count+null_final_count+null_recc_count+null_both_count+equal_count as cum_sum
            FROM less_severe,more_severe,null_recc, null_final,null_both,equal
            WHERE less_severe.category = more_severe.category AND less_severe.category = null_recc.category AND less_severe.category = null_final.category
            AND less_severe.category = null_both.category AND less_severe.category = equal.category)
SELECT less_severe.category, ROUND(100.0*null_both_count/cum_sum,2) as pct_null_both, ROUND(100.0*equal_count/cum_sum,2) as pct_equal, ROUND(100.0*less_severe_count/cum_sum,2) as pct_less_severe, ROUND(100.0*more_severe_count/cum_sum,2) as pct_more_severe, ROUND(100.0*null_final_count/cum_sum,2) as pct_null_final, ROUND(100.0*null_recc_count/cum_sum,2) as pct_null_rec, cum_sum as count
FROM less_severe,more_severe,null_recc, null_final,null_both, equal, sum
WHERE less_severe.category = more_severe.category AND less_severe.category = null_recc.category AND less_severe.category = null_final.category
    AND less_severe.category = null_both.category AND sum.category = less_severe.category AND less_severe.category = equal.category
ORDER BY pct_null_both DESC;

-- ORDER BY PERCENT OF DATA WITH ANY NULL --
WITH count_table AS (SELECT category, tmp5.recc_severity, tmp5.final_severity
                     FROM (SELECT category, allegation_category_id, tmp4.recc_severity, tmp4.final_severity, DAC.id
                          FROM data_allegationcategory as DAC
                          LEFT JOIN (SELECT tmp2.allegation_category_id, tmp2.officer_id, tmp2.allegation_id, tmp2.severity as recc_severity, tmp3.severity as final_severity
                                                                  FROM (SELECT *
                                                                        FROM data_officerallegation as DOA
                                                                        JOIN tmp ON DOA.recc_outcome ILIKE tmp.outcome) as tmp2,
                                                                        (SELECT *
                                                                         FROM data_officerallegation as DOA
                                                                         JOIN tmp ON DOA.final_outcome ILIKE tmp.outcome) as tmp3
                                                                  WHERE tmp2.id = tmp3.id) AS tmp4
                    ON tmp4.allegation_category_id = DAC.id) as tmp5),
    less_severe AS (SELECT tmp7.category, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS less_severe_count
                   FROM (SELECT DISTINCT category FROM data_allegationcategory) as tmp7
                   LEFT JOIN (SELECT category, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity > count_table.final_severity
                   GROUP BY category) as tmp6 ON tmp6.category = tmp7.category),
    more_severe AS (SELECT tmp7.category, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS more_severe_count
                   FROM (SELECT DISTINCT category FROM data_allegationcategory) as tmp7
                   LEFT JOIN (SELECT category, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity < count_table.final_severity
                   GROUP BY category) as tmp6 ON tmp6.category = tmp7.category),
    null_final AS (SELECT tmp7.category, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS null_final_count
                   FROM (SELECT DISTINCT category FROM data_allegationcategory) as tmp7
                   LEFT JOIN (SELECT category, count(*)
                   FROM count_table
                   WHERE count_table.final_severity IS NULL AND count_table.recc_severity IS NOT NULL
                   GROUP BY category) as tmp6 ON tmp6.category = tmp7.category),
    null_recc AS (SELECT tmp7.category, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS null_recc_count
                   FROM (SELECT DISTINCT category FROM data_allegationcategory) as tmp7
                   LEFT JOIN (SELECT category, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity IS NULL AND count_table.final_severity IS NOT NULL
                   GROUP BY category) as tmp6 ON tmp6.category = tmp7.category),
    null_both AS (SELECT tmp7.category, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS null_both_count
                   FROM (SELECT DISTINCT category FROM data_allegationcategory) as tmp7
                   LEFT JOIN (SELECT category, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity IS NULL AND count_table.final_severity IS NULL
                   GROUP BY category) as tmp6 ON tmp6.category = tmp7.category),
     equal AS (SELECT tmp7.category, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS equal_count
                   FROM (SELECT DISTINCT category FROM data_allegationcategory) as tmp7
                   LEFT JOIN (SELECT category, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity = count_table.final_severity
                   GROUP BY category) as tmp6 ON tmp6.category = tmp7.category),
    sum AS (SELECT less_severe.category, less_severe_count+more_severe_count+null_final_count+null_recc_count+null_both_count+equal_count as cum_sum
            FROM less_severe,more_severe,null_recc, null_final,null_both,equal
            WHERE less_severe.category = more_severe.category AND less_severe.category = null_recc.category AND less_severe.category = null_final.category
            AND less_severe.category = null_both.category AND less_severe.category = equal.category)
SELECT less_severe.category, ROUND(100.0*null_final_count/cum_sum,2) as pct_null_final, ROUND(100.0*null_recc_count/cum_sum,2) as pct_null_rec, ROUND(100.0*null_both_count/cum_sum,2) as pct_null_both, ROUND(100.0*equal_count/cum_sum,2) as pct_equal, ROUND(100.0*less_severe_count/cum_sum,2) as pct_less_severe, ROUND(100.0*more_severe_count/cum_sum,2) as pct_more_severe, cum_sum as count
FROM less_severe,more_severe,null_recc, null_final,null_both, equal, sum
WHERE less_severe.category = more_severe.category AND less_severe.category = null_recc.category AND less_severe.category = null_final.category
    AND less_severe.category = null_both.category AND sum.category = less_severe.category AND less_severe.category = equal.category
ORDER BY ROUND(100.0*null_final_count/cum_sum,2) + ROUND(100.0*null_recc_count/cum_sum,2) + ROUND(100.0*null_both_count/cum_sum,2) DESC;