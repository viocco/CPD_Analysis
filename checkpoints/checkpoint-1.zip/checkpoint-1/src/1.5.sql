-- Question 1: Is there sufficient data to analyze the discrepancies in recommended and final outcomes and findings? --
--  1.1) What are the unique categories for a final finding? When grouped by final finding, what are the allegation counts?
--       When grouped by final finding, what is the percent of allegations in each category?
--  1.2) What are the unique categories for a final outcome? When grouped by final outcome, what are the allegation counts?
--       When grouped by final outcome, what is the percent of allegations in each category?
--  1.3) What are the unique categories for a recommended finding? When grouped by recommended finding, what are the allegation
--       counts? When grouped by recommended finding, what is the percent of allegations in each category?
--  1.4) What are the unique categories for a recommended outcome? When grouped by recommended outcome, what are the allegation
--       counts? When grouped by recommended outcome, what is the percent of allegations in each category?
--  1.5) When grouped by final finding, what is the percentage of each final outcome as a percent of the total
--       outcomes for that final finding? What are the counts?

DROP TABLE IF EXISTS tmp_data_officerallegation;
SELECT * INTO tmp_data_officerallegation FROM data_officerallegation;
UPDATE tmp_data_officerallegation SET final_outcome='Suspended' WHERE final_outcome ILIKE '%Suspen%';

SELECT DOA.final_finding, final_outcome, count(*), ROUND(count(*)*100.0/(SELECT count(*) FROM tmp_data_officerallegation AS DOA),3) AS percent
FROM tmp_data_officerallegation AS DOA
GROUP BY DOA.final_finding, DOA.final_outcome
ORDER BY DOA.final_finding, percent DESC;

SELECT tem.final_finding                   as final_finding,
       tem.final_outcome           as final_outcome,
       ROUND((100.0 * tem.N) / total.N ,2) as Pct,
       tem.N                      as count
FROM ( SELECT final_finding, final_outcome, count(*) as N
       FROM tmp_data_officerallegation
       GROUP BY final_finding, final_outcome
     ) tem
JOIN ( SELECT final_finding , count(*) as N
       FROM tmp_data_officerallegation
       GROUP BY final_finding
     ) total ON tem.final_finding = total.final_finding
ORDER BY tem.final_finding, Pct DESC;
