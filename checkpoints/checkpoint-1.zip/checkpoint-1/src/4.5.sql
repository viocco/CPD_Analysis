-- Question 4:  Is there a correlation between the race of the victim and the rate at which the recommended finding and outcome are finalized?  --
--  1) When grouped by the race of the victim, what is the distribution of recommended findings as counts and percentages of the
--     race's total allegations?
--  2) When grouped by the race of the victim, what is the distribution of final findings as counts and percentages of the race's
--     total allegations?
--  3) When grouped by the race of the victim, what is the distribution of recommended outcomes as counts and percentages of the
--     race's total allegations?
--  4) When grouped by the race of the victim, what is the distribution of final outcomes as counts and percentages of the race's
--     total allegations?
--  5) When grouped by race of victim, what percent of complaints in each race have a more/less severe recommended finding than
--     final finding (as a percent of? What percent of complaints in each allegation category have recommended findings or final findings that are null/unknown?
--  6) When grouped by race of victim, what percent of complaints in each race have a more/less severe recommended outcome than
--     final outcome?  What percent of complaints in each allegation category have recommended outcomes or final outcomes are
--     null/unknown?

-- // Create a temporary table
DROP TABLE IF EXISTS tmp;
CREATE TEMPORARY TABLE tmp (finding varchar(2), severity int, PRIMARY KEY(finding));
INSERT INTO tmp(finding,severity) VALUES ('SU', 1),
                                         ('UN', 3),
                                         ('EX', 3),
                                         ('NS', 2),
                                         ('NA', 3),
                                         ('',NULL);

--      categories AS (SELECT race, category, final_severity FROM count_table, data_allegationcategory WHERE count_table.)
-- ORDER BY PERCENT EQUAL --
WITH count_table AS (SELECT race, tmp5.recc_severity, tmp5.final_severity, tmp5.crid
                     FROM (SELECT race, tmp4.recc_severity, tmp4.final_severity, DA.crid
                          FROM data_allegation as DA, data_victim DV, (SELECT tmp2.officer_id, tmp2.allegation_id, tmp2.severity as recc_severity, tmp3.severity as final_severity
                                                                        FROM (SELECT *
                                                                              FROM data_officerallegation as DOA
                                                                              JOIN tmp ON DOA.recc_finding ILIKE tmp.finding) as tmp2,
                                                                              (SELECT *
                                                                               FROM data_officerallegation as DOA
                                                                               JOIN tmp ON DOA.final_finding ILIKE tmp.finding) as tmp3
                                                                        WHERE tmp2.id = tmp3.id) AS tmp4
                    WHERE DA.crid = tmp4.allegation_id AND DV.allegation_id = DA.crid) as tmp5),

    less_severe AS (SELECT tmp7.race, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS less_severe_count
                   FROM (SELECT DISTINCT race FROM data_victim) as tmp7
                   LEFT JOIN (SELECT race, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity > count_table.final_severity AND count_table.recc_severity IS NOT NULL AND count_table.final_severity IS NOT NULL
                   GROUP BY race) as tmp6 ON tmp6.race = tmp7.race),
    more_severe AS (SELECT tmp7.race, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS more_severe_count
                   FROM (SELECT DISTINCT race FROM data_victim) as tmp7
                   LEFT JOIN (SELECT race, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity < count_table.final_severity AND count_table.recc_severity IS NOT NULL AND count_table.final_severity IS NOT NULL
                   GROUP BY race) as tmp6 ON tmp6.race = tmp7.race),
    null_final AS (SELECT tmp7.race, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS null_final_count
                   FROM (SELECT DISTINCT race FROM data_victim) as tmp7
                   LEFT JOIN (SELECT race, count(*)
                   FROM count_table
                   WHERE count_table.final_severity IS NULL AND count_table.recc_severity IS NOT NULL
                   GROUP BY race) as tmp6 ON tmp6.race = tmp7.race),
    null_recc AS (SELECT tmp7.race, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS null_recc_count
                   FROM (SELECT DISTINCT race FROM data_victim) as tmp7
                   LEFT JOIN (SELECT race, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity IS NULL AND count_table.final_severity IS NOT NULL
                   GROUP BY race) as tmp6 ON tmp6.race = tmp7.race),
    null_both AS (SELECT tmp7.race, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS null_both_count
                   FROM (SELECT DISTINCT race FROM data_victim) as tmp7
                   LEFT JOIN (SELECT race, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity IS NULL AND count_table.final_severity IS NULL
                   GROUP BY race) as tmp6 ON tmp6.race = tmp7.race),
     equal AS (SELECT tmp7.race, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS equal_count
                   FROM (SELECT DISTINCT race FROM data_victim) as tmp7
                   LEFT JOIN (SELECT race, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity = count_table.final_severity
                   GROUP BY race) as tmp6 ON tmp6.race = tmp7.race),
    sum AS (SELECT less_severe.race, less_severe_count+more_severe_count+null_final_count+null_recc_count+null_both_count+equal_count as cum_sum
            FROM less_severe,more_severe,null_recc, null_final,null_both,equal
            WHERE less_severe.race = more_severe.race AND less_severe.race = null_recc.race AND less_severe.race = null_final.race
            AND less_severe.race = null_both.race AND less_severe.race = equal.race)
SELECT less_severe.race, ROUND(100.0*equal_count/cum_sum,2) as pct_equal, ROUND(100.0*less_severe_count/cum_sum,2) as pct_less_severe, ROUND(100.0*more_severe_count/cum_sum,2) as pct_more_severe, ROUND(100.0*null_final_count/cum_sum,2) as pct_null_final, ROUND(100.0*null_recc_count/cum_sum,2) as pct_null_rec, ROUND(100.0*null_both_count/cum_sum,2) as pct_null_both, cum_sum as count
FROM less_severe,more_severe,null_recc, null_final,null_both, equal, sum
WHERE less_severe.race = more_severe.race AND less_severe.race = null_recc.race AND less_severe.race = null_final.race
    AND less_severe.race = null_both.race AND sum.race = less_severe.race AND less_severe.race = equal.race
ORDER BY pct_equal DESC;


-- ORDER BY PERCENT LESS SEVERE --
WITH count_table AS (SELECT race, tmp5.recc_severity, tmp5.final_severity, tmp5.crid
                     FROM (SELECT race, tmp4.recc_severity, tmp4.final_severity, DA.crid
                          FROM data_allegation as DA, data_victim DV, (SELECT tmp2.officer_id, tmp2.allegation_id, tmp2.severity as recc_severity, tmp3.severity as final_severity
                                                                        FROM (SELECT *
                                                                              FROM data_officerallegation as DOA
                                                                              JOIN tmp ON DOA.recc_finding ILIKE tmp.finding) as tmp2,
                                                                              (SELECT *
                                                                               FROM data_officerallegation as DOA
                                                                               JOIN tmp ON DOA.final_finding ILIKE tmp.finding) as tmp3
                                                                        WHERE tmp2.id = tmp3.id) AS tmp4
                    WHERE DA.crid = tmp4.allegation_id AND DV.allegation_id = DA.crid) as tmp5),

    less_severe AS (SELECT tmp7.race, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS less_severe_count
                   FROM (SELECT DISTINCT race FROM data_victim) as tmp7
                   LEFT JOIN (SELECT race, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity > count_table.final_severity AND count_table.recc_severity IS NOT NULL AND count_table.final_severity IS NOT NULL
                   GROUP BY race) as tmp6 ON tmp6.race = tmp7.race),
    more_severe AS (SELECT tmp7.race, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS more_severe_count
                   FROM (SELECT DISTINCT race FROM data_victim) as tmp7
                   LEFT JOIN (SELECT race, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity < count_table.final_severity AND count_table.recc_severity IS NOT NULL AND count_table.final_severity IS NOT NULL
                   GROUP BY race) as tmp6 ON tmp6.race = tmp7.race),
    null_final AS (SELECT tmp7.race, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS null_final_count
                   FROM (SELECT DISTINCT race FROM data_victim) as tmp7
                   LEFT JOIN (SELECT race, count(*)
                   FROM count_table
                   WHERE count_table.final_severity IS NULL AND count_table.recc_severity IS NOT NULL
                   GROUP BY race) as tmp6 ON tmp6.race = tmp7.race),
    null_recc AS (SELECT tmp7.race, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS null_recc_count
                   FROM (SELECT DISTINCT race FROM data_victim) as tmp7
                   LEFT JOIN (SELECT race, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity IS NULL AND count_table.final_severity IS NOT NULL
                   GROUP BY race) as tmp6 ON tmp6.race = tmp7.race),
    null_both AS (SELECT tmp7.race, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS null_both_count
                   FROM (SELECT DISTINCT race FROM data_victim) as tmp7
                   LEFT JOIN (SELECT race, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity IS NULL AND count_table.final_severity IS NULL
                   GROUP BY race) as tmp6 ON tmp6.race = tmp7.race),
     equal AS (SELECT tmp7.race, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS equal_count
                   FROM (SELECT DISTINCT race FROM data_victim) as tmp7
                   LEFT JOIN (SELECT race, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity = count_table.final_severity
                   GROUP BY race) as tmp6 ON tmp6.race = tmp7.race),
    sum AS (SELECT less_severe.race, less_severe_count+more_severe_count+null_final_count+null_recc_count+null_both_count+equal_count as cum_sum
            FROM less_severe,more_severe,null_recc, null_final,null_both,equal
            WHERE less_severe.race = more_severe.race AND less_severe.race = null_recc.race AND less_severe.race = null_final.race
            AND less_severe.race = null_both.race AND less_severe.race = equal.race)
SELECT less_severe.race, ROUND(100.0*less_severe_count/cum_sum,2) as pct_less_severe,ROUND(100.0*equal_count/cum_sum,2) as pct_equal, ROUND(100.0*more_severe_count/cum_sum,2) as pct_more_severe, ROUND(100.0*null_final_count/cum_sum,2) as pct_null_final, ROUND(100.0*null_recc_count/cum_sum,2) as pct_null_rec, ROUND(100.0*null_both_count/cum_sum,2) as pct_null_both, cum_sum as count
FROM less_severe,more_severe,null_recc, null_final,null_both, equal, sum
WHERE less_severe.race = more_severe.race AND less_severe.race = null_recc.race AND less_severe.race = null_final.race
    AND less_severe.race = null_both.race AND sum.race = less_severe.race AND less_severe.race = equal.race
ORDER BY pct_less_severe DESC;

-- ORDER BY PERCENT MORE SEVERE --
WITH count_table AS (SELECT race, tmp5.recc_severity, tmp5.final_severity, tmp5.crid
                     FROM (SELECT race, tmp4.recc_severity, tmp4.final_severity, DA.crid
                          FROM data_allegation as DA, data_victim DV, (SELECT tmp2.officer_id, tmp2.allegation_id, tmp2.severity as recc_severity, tmp3.severity as final_severity
                                                                        FROM (SELECT *
                                                                              FROM data_officerallegation as DOA
                                                                              JOIN tmp ON DOA.recc_finding ILIKE tmp.finding) as tmp2,
                                                                              (SELECT *
                                                                               FROM data_officerallegation as DOA
                                                                               JOIN tmp ON DOA.final_finding ILIKE tmp.finding) as tmp3
                                                                        WHERE tmp2.id = tmp3.id) AS tmp4
                    WHERE DA.crid = tmp4.allegation_id AND DV.allegation_id = DA.crid) as tmp5),

    less_severe AS (SELECT tmp7.race, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS less_severe_count
                   FROM (SELECT DISTINCT race FROM data_victim) as tmp7
                   LEFT JOIN (SELECT race, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity > count_table.final_severity AND count_table.recc_severity IS NOT NULL AND count_table.final_severity IS NOT NULL
                   GROUP BY race) as tmp6 ON tmp6.race = tmp7.race),
    more_severe AS (SELECT tmp7.race, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS more_severe_count
                   FROM (SELECT DISTINCT race FROM data_victim) as tmp7
                   LEFT JOIN (SELECT race, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity < count_table.final_severity AND count_table.recc_severity IS NOT NULL AND count_table.final_severity IS NOT NULL
                   GROUP BY race) as tmp6 ON tmp6.race = tmp7.race),
    null_final AS (SELECT tmp7.race, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS null_final_count
                   FROM (SELECT DISTINCT race FROM data_victim) as tmp7
                   LEFT JOIN (SELECT race, count(*)
                   FROM count_table
                   WHERE count_table.final_severity IS NULL AND count_table.recc_severity IS NOT NULL
                   GROUP BY race) as tmp6 ON tmp6.race = tmp7.race),
    null_recc AS (SELECT tmp7.race, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS null_recc_count
                   FROM (SELECT DISTINCT race FROM data_victim) as tmp7
                   LEFT JOIN (SELECT race, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity IS NULL AND count_table.final_severity IS NOT NULL
                   GROUP BY race) as tmp6 ON tmp6.race = tmp7.race),
    null_both AS (SELECT tmp7.race, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS null_both_count
                   FROM (SELECT DISTINCT race FROM data_victim) as tmp7
                   LEFT JOIN (SELECT race, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity IS NULL AND count_table.final_severity IS NULL
                   GROUP BY race) as tmp6 ON tmp6.race = tmp7.race),
     equal AS (SELECT tmp7.race, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS equal_count
                   FROM (SELECT DISTINCT race FROM data_victim) as tmp7
                   LEFT JOIN (SELECT race, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity = count_table.final_severity
                   GROUP BY race) as tmp6 ON tmp6.race = tmp7.race),
    sum AS (SELECT less_severe.race, less_severe_count+more_severe_count+null_final_count+null_recc_count+null_both_count+equal_count as cum_sum
            FROM less_severe,more_severe,null_recc, null_final,null_both,equal
            WHERE less_severe.race = more_severe.race AND less_severe.race = null_recc.race AND less_severe.race = null_final.race
            AND less_severe.race = null_both.race AND less_severe.race = equal.race)
SELECT less_severe.race, ROUND(100.0*more_severe_count/cum_sum,2) as pct_more_severe, ROUND(100.0*equal_count/cum_sum,2) as pct_equal, ROUND(100.0*less_severe_count/cum_sum,2) as pct_less_severe, ROUND(100.0*null_final_count/cum_sum,2) as pct_null_final, ROUND(100.0*null_recc_count/cum_sum,2) as pct_null_rec, ROUND(100.0*null_both_count/cum_sum,2) as pct_null_both, cum_sum as count
FROM less_severe,more_severe,null_recc, null_final,null_both, equal, sum
WHERE less_severe.race = more_severe.race AND less_severe.race = null_recc.race AND less_severe.race = null_final.race
    AND less_severe.race = null_both.race AND sum.race = less_severe.race AND less_severe.race = equal.race
ORDER BY pct_more_severe DESC;

-- ORDER BY PERCENT OF DATA WITH ONLY RECC NULL --
WITH count_table AS (SELECT race, tmp5.recc_severity, tmp5.final_severity, tmp5.crid
                     FROM (SELECT race, tmp4.recc_severity, tmp4.final_severity, DA.crid
                          FROM data_allegation as DA, data_victim DV, (SELECT tmp2.officer_id, tmp2.allegation_id, tmp2.severity as recc_severity, tmp3.severity as final_severity
                                                                        FROM (SELECT *
                                                                              FROM data_officerallegation as DOA
                                                                              JOIN tmp ON DOA.recc_finding ILIKE tmp.finding) as tmp2,
                                                                              (SELECT *
                                                                               FROM data_officerallegation as DOA
                                                                               JOIN tmp ON DOA.final_finding ILIKE tmp.finding) as tmp3
                                                                        WHERE tmp2.id = tmp3.id) AS tmp4
                    WHERE DA.crid = tmp4.allegation_id AND DV.allegation_id = DA.crid) as tmp5),

    less_severe AS (SELECT tmp7.race, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS less_severe_count
                   FROM (SELECT DISTINCT race FROM data_victim) as tmp7
                   LEFT JOIN (SELECT race, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity > count_table.final_severity AND count_table.recc_severity IS NOT NULL AND count_table.final_severity IS NOT NULL
                   GROUP BY race) as tmp6 ON tmp6.race = tmp7.race),
    more_severe AS (SELECT tmp7.race, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS more_severe_count
                   FROM (SELECT DISTINCT race FROM data_victim) as tmp7
                   LEFT JOIN (SELECT race, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity < count_table.final_severity AND count_table.recc_severity IS NOT NULL AND count_table.final_severity IS NOT NULL
                   GROUP BY race) as tmp6 ON tmp6.race = tmp7.race),
    null_final AS (SELECT tmp7.race, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS null_final_count
                   FROM (SELECT DISTINCT race FROM data_victim) as tmp7
                   LEFT JOIN (SELECT race, count(*)
                   FROM count_table
                   WHERE count_table.final_severity IS NULL AND count_table.recc_severity IS NOT NULL
                   GROUP BY race) as tmp6 ON tmp6.race = tmp7.race),
    null_recc AS (SELECT tmp7.race, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS null_recc_count
                   FROM (SELECT DISTINCT race FROM data_victim) as tmp7
                   LEFT JOIN (SELECT race, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity IS NULL AND count_table.final_severity IS NOT NULL
                   GROUP BY race) as tmp6 ON tmp6.race = tmp7.race),
    null_both AS (SELECT tmp7.race, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS null_both_count
                   FROM (SELECT DISTINCT race FROM data_victim) as tmp7
                   LEFT JOIN (SELECT race, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity IS NULL AND count_table.final_severity IS NULL
                   GROUP BY race) as tmp6 ON tmp6.race = tmp7.race),
     equal AS (SELECT tmp7.race, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS equal_count
                   FROM (SELECT DISTINCT race FROM data_victim) as tmp7
                   LEFT JOIN (SELECT race, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity = count_table.final_severity
                   GROUP BY race) as tmp6 ON tmp6.race = tmp7.race),
    sum AS (SELECT less_severe.race, less_severe_count+more_severe_count+null_final_count+null_recc_count+null_both_count+equal_count as cum_sum
            FROM less_severe,more_severe,null_recc, null_final,null_both,equal
            WHERE less_severe.race = more_severe.race AND less_severe.race = null_recc.race AND less_severe.race = null_final.race
            AND less_severe.race = null_both.race AND less_severe.race = equal.race)
SELECT less_severe.race, ROUND(100.0*null_recc_count/cum_sum,2) as pct_null_rec, ROUND(100.0*equal_count/cum_sum,2) as pct_equal, ROUND(100.0*less_severe_count/cum_sum,2) as pct_less_severe, ROUND(100.0*more_severe_count/cum_sum,2) as pct_more_severe, ROUND(100.0*null_final_count/cum_sum,2) as pct_null_final, ROUND(100.0*null_both_count/cum_sum,2) as pct_null_both, cum_sum as count
FROM less_severe,more_severe,null_recc, null_final,null_both, equal, sum
WHERE less_severe.race = more_severe.race AND less_severe.race = null_recc.race AND less_severe.race = null_final.race
    AND less_severe.race = null_both.race AND sum.race = less_severe.race AND less_severe.race = equal.race
ORDER BY pct_null_rec DESC;

-- ORDER BY PERCENT OF DATA WITH ONLY FINAL NULL --
WITH count_table AS (SELECT race, tmp5.recc_severity, tmp5.final_severity, tmp5.crid
                     FROM (SELECT race, tmp4.recc_severity, tmp4.final_severity, DA.crid
                          FROM data_allegation as DA, data_victim DV, (SELECT tmp2.officer_id, tmp2.allegation_id, tmp2.severity as recc_severity, tmp3.severity as final_severity
                                                                        FROM (SELECT *
                                                                              FROM data_officerallegation as DOA
                                                                              JOIN tmp ON DOA.recc_finding ILIKE tmp.finding) as tmp2,
                                                                              (SELECT *
                                                                               FROM data_officerallegation as DOA
                                                                               JOIN tmp ON DOA.final_finding ILIKE tmp.finding) as tmp3
                                                                        WHERE tmp2.id = tmp3.id) AS tmp4
                    WHERE DA.crid = tmp4.allegation_id AND DV.allegation_id = DA.crid) as tmp5),

    less_severe AS (SELECT tmp7.race, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS less_severe_count
                   FROM (SELECT DISTINCT race FROM data_victim) as tmp7
                   LEFT JOIN (SELECT race, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity > count_table.final_severity AND count_table.recc_severity IS NOT NULL AND count_table.final_severity IS NOT NULL
                   GROUP BY race) as tmp6 ON tmp6.race = tmp7.race),
    more_severe AS (SELECT tmp7.race, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS more_severe_count
                   FROM (SELECT DISTINCT race FROM data_victim) as tmp7
                   LEFT JOIN (SELECT race, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity < count_table.final_severity AND count_table.recc_severity IS NOT NULL AND count_table.final_severity IS NOT NULL
                   GROUP BY race) as tmp6 ON tmp6.race = tmp7.race),
    null_final AS (SELECT tmp7.race, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS null_final_count
                   FROM (SELECT DISTINCT race FROM data_victim) as tmp7
                   LEFT JOIN (SELECT race, count(*)
                   FROM count_table
                   WHERE count_table.final_severity IS NULL AND count_table.recc_severity IS NOT NULL
                   GROUP BY race) as tmp6 ON tmp6.race = tmp7.race),
    null_recc AS (SELECT tmp7.race, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS null_recc_count
                   FROM (SELECT DISTINCT race FROM data_victim) as tmp7
                   LEFT JOIN (SELECT race, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity IS NULL AND count_table.final_severity IS NOT NULL
                   GROUP BY race) as tmp6 ON tmp6.race = tmp7.race),
    null_both AS (SELECT tmp7.race, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS null_both_count
                   FROM (SELECT DISTINCT race FROM data_victim) as tmp7
                   LEFT JOIN (SELECT race, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity IS NULL AND count_table.final_severity IS NULL
                   GROUP BY race) as tmp6 ON tmp6.race = tmp7.race),
     equal AS (SELECT tmp7.race, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS equal_count
                   FROM (SELECT DISTINCT race FROM data_victim) as tmp7
                   LEFT JOIN (SELECT race, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity = count_table.final_severity
                   GROUP BY race) as tmp6 ON tmp6.race = tmp7.race),
    sum AS (SELECT less_severe.race, less_severe_count+more_severe_count+null_final_count+null_recc_count+null_both_count+equal_count as cum_sum
            FROM less_severe,more_severe,null_recc, null_final,null_both,equal
            WHERE less_severe.race = more_severe.race AND less_severe.race = null_recc.race AND less_severe.race = null_final.race
            AND less_severe.race = null_both.race AND less_severe.race = equal.race)
SELECT less_severe.race, ROUND(100.0*null_final_count/cum_sum,2) as pct_null_final, ROUND(100.0*equal_count/cum_sum,2) as pct_equal, ROUND(100.0*less_severe_count/cum_sum,2) as pct_less_severe, ROUND(100.0*more_severe_count/cum_sum,2) as pct_more_severe, ROUND(100.0*null_recc_count/cum_sum,2) as pct_null_rec, ROUND(100.0*null_both_count/cum_sum,2) as pct_null_both, cum_sum as count
FROM less_severe,more_severe,null_recc, null_final,null_both, equal, sum
WHERE less_severe.race = more_severe.race AND less_severe.race = null_recc.race AND less_severe.race = null_final.race
    AND less_severe.race = null_both.race AND sum.race = less_severe.race AND less_severe.race = equal.race
ORDER BY pct_null_final DESC;

-- ORDER BY PERCENT OF DATA WITH BOTH NULL --
WITH count_table AS (SELECT race, tmp5.recc_severity, tmp5.final_severity, tmp5.crid
                     FROM (SELECT race, tmp4.recc_severity, tmp4.final_severity, DA.crid
                          FROM data_allegation as DA, data_victim DV, (SELECT tmp2.officer_id, tmp2.allegation_id, tmp2.severity as recc_severity, tmp3.severity as final_severity
                                                                        FROM (SELECT *
                                                                              FROM data_officerallegation as DOA
                                                                              JOIN tmp ON DOA.recc_finding ILIKE tmp.finding) as tmp2,
                                                                              (SELECT *
                                                                               FROM data_officerallegation as DOA
                                                                               JOIN tmp ON DOA.final_finding ILIKE tmp.finding) as tmp3
                                                                        WHERE tmp2.id = tmp3.id) AS tmp4
                    WHERE DA.crid = tmp4.allegation_id AND DV.allegation_id = DA.crid) as tmp5),

    less_severe AS (SELECT tmp7.race, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS less_severe_count
                   FROM (SELECT DISTINCT race FROM data_victim) as tmp7
                   LEFT JOIN (SELECT race, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity > count_table.final_severity AND count_table.recc_severity IS NOT NULL AND count_table.final_severity IS NOT NULL
                   GROUP BY race) as tmp6 ON tmp6.race = tmp7.race),
    more_severe AS (SELECT tmp7.race, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS more_severe_count
                   FROM (SELECT DISTINCT race FROM data_victim) as tmp7
                   LEFT JOIN (SELECT race, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity < count_table.final_severity AND count_table.recc_severity IS NOT NULL AND count_table.final_severity IS NOT NULL
                   GROUP BY race) as tmp6 ON tmp6.race = tmp7.race),
    null_final AS (SELECT tmp7.race, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS null_final_count
                   FROM (SELECT DISTINCT race FROM data_victim) as tmp7
                   LEFT JOIN (SELECT race, count(*)
                   FROM count_table
                   WHERE count_table.final_severity IS NULL AND count_table.recc_severity IS NOT NULL
                   GROUP BY race) as tmp6 ON tmp6.race = tmp7.race),
    null_recc AS (SELECT tmp7.race, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS null_recc_count
                   FROM (SELECT DISTINCT race FROM data_victim) as tmp7
                   LEFT JOIN (SELECT race, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity IS NULL AND count_table.final_severity IS NOT NULL
                   GROUP BY race) as tmp6 ON tmp6.race = tmp7.race),
    null_both AS (SELECT tmp7.race, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS null_both_count
                   FROM (SELECT DISTINCT race FROM data_victim) as tmp7
                   LEFT JOIN (SELECT race, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity IS NULL AND count_table.final_severity IS NULL
                   GROUP BY race) as tmp6 ON tmp6.race = tmp7.race),
     equal AS (SELECT tmp7.race, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS equal_count
                   FROM (SELECT DISTINCT race FROM data_victim) as tmp7
                   LEFT JOIN (SELECT race, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity = count_table.final_severity
                   GROUP BY race) as tmp6 ON tmp6.race = tmp7.race),
    sum AS (SELECT less_severe.race, less_severe_count+more_severe_count+null_final_count+null_recc_count+null_both_count+equal_count as cum_sum
            FROM less_severe,more_severe,null_recc, null_final,null_both,equal
            WHERE less_severe.race = more_severe.race AND less_severe.race = null_recc.race AND less_severe.race = null_final.race
            AND less_severe.race = null_both.race AND less_severe.race = equal.race)
SELECT less_severe.race, ROUND(100.0*null_both_count/cum_sum,2) as pct_null_both, ROUND(100.0*equal_count/cum_sum,2) as pct_equal, ROUND(100.0*less_severe_count/cum_sum,2) as pct_less_severe, ROUND(100.0*more_severe_count/cum_sum,2) as pct_more_severe, ROUND(100.0*null_final_count/cum_sum,2) as pct_null_final, ROUND(100.0*null_recc_count/cum_sum,2) as pct_null_rec, cum_sum as count
FROM less_severe,more_severe,null_recc, null_final,null_both, equal, sum
WHERE less_severe.race = more_severe.race AND less_severe.race = null_recc.race AND less_severe.race = null_final.race
    AND less_severe.race = null_both.race AND sum.race = less_severe.race AND less_severe.race = equal.race
ORDER BY pct_null_both DESC;

-- ORDER BY PERCENT OF DATA WITH ANY NULL --
WITH count_table AS (SELECT race, tmp5.recc_severity, tmp5.final_severity, tmp5.crid
                     FROM (SELECT race, tmp4.recc_severity, tmp4.final_severity, DA.crid
                          FROM data_allegation as DA, data_victim DV, (SELECT tmp2.officer_id, tmp2.allegation_id, tmp2.severity as recc_severity, tmp3.severity as final_severity
                                                                        FROM (SELECT *
                                                                              FROM data_officerallegation as DOA
                                                                              JOIN tmp ON DOA.recc_finding ILIKE tmp.finding) as tmp2,
                                                                              (SELECT *
                                                                               FROM data_officerallegation as DOA
                                                                               JOIN tmp ON DOA.final_finding ILIKE tmp.finding) as tmp3
                                                                        WHERE tmp2.id = tmp3.id) AS tmp4
                    WHERE DA.crid = tmp4.allegation_id AND DV.allegation_id = DA.crid) as tmp5),

    less_severe AS (SELECT tmp7.race, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS less_severe_count
                   FROM (SELECT DISTINCT race FROM data_victim) as tmp7
                   LEFT JOIN (SELECT race, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity > count_table.final_severity AND count_table.recc_severity IS NOT NULL AND count_table.final_severity IS NOT NULL
                   GROUP BY race) as tmp6 ON tmp6.race = tmp7.race),
    more_severe AS (SELECT tmp7.race, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS more_severe_count
                   FROM (SELECT DISTINCT race FROM data_victim) as tmp7
                   LEFT JOIN (SELECT race, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity < count_table.final_severity AND count_table.recc_severity IS NOT NULL AND count_table.final_severity IS NOT NULL
                   GROUP BY race) as tmp6 ON tmp6.race = tmp7.race),
    null_final AS (SELECT tmp7.race, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS null_final_count
                   FROM (SELECT DISTINCT race FROM data_victim) as tmp7
                   LEFT JOIN (SELECT race, count(*)
                   FROM count_table
                   WHERE count_table.final_severity IS NULL AND count_table.recc_severity IS NOT NULL
                   GROUP BY race) as tmp6 ON tmp6.race = tmp7.race),
    null_recc AS (SELECT tmp7.race, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS null_recc_count
                   FROM (SELECT DISTINCT race FROM data_victim) as tmp7
                   LEFT JOIN (SELECT race, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity IS NULL AND count_table.final_severity IS NOT NULL
                   GROUP BY race) as tmp6 ON tmp6.race = tmp7.race),
    null_both AS (SELECT tmp7.race, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS null_both_count
                   FROM (SELECT DISTINCT race FROM data_victim) as tmp7
                   LEFT JOIN (SELECT race, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity IS NULL AND count_table.final_severity IS NULL
                   GROUP BY race) as tmp6 ON tmp6.race = tmp7.race),
     equal AS (SELECT tmp7.race, CASE WHEN tmp6.count IS NULL THEN 0 ELSE tmp6.count END AS equal_count
                   FROM (SELECT DISTINCT race FROM data_victim) as tmp7
                   LEFT JOIN (SELECT race, count(*)
                   FROM count_table
                   WHERE count_table.recc_severity = count_table.final_severity
                   GROUP BY race) as tmp6 ON tmp6.race = tmp7.race),
    sum AS (SELECT less_severe.race, less_severe_count+more_severe_count+null_final_count+null_recc_count+null_both_count+equal_count as cum_sum
            FROM less_severe,more_severe,null_recc, null_final,null_both,equal
            WHERE less_severe.race = more_severe.race AND less_severe.race = null_recc.race AND less_severe.race = null_final.race
            AND less_severe.race = null_both.race AND less_severe.race = equal.race)
SELECT less_severe.race, ROUND(100.0*null_recc_count/cum_sum,2) as pct_null_rec, ROUND(100.0*null_final_count/cum_sum,2) as pct_null_final, ROUND(100.0*null_both_count/cum_sum,2) as pct_null_both, ROUND(100.0*equal_count/cum_sum,2) as pct_equal, ROUND(100.0*less_severe_count/cum_sum,2) as pct_less_severe, ROUND(100.0*more_severe_count/cum_sum,2) as pct_more_severe, cum_sum as count
FROM less_severe,more_severe,null_recc, null_final,null_both, equal, sum
WHERE less_severe.race = more_severe.race AND less_severe.race = null_recc.race AND less_severe.race = null_final.race
    AND less_severe.race = null_both.race AND sum.race = less_severe.race AND less_severe.race = equal.race
ORDER BY ROUND(100.0*null_recc_count/cum_sum,2) + ROUND(100.0*null_final_count/cum_sum,2) + ROUND(100.0*null_both_count/cum_sum,2) DESC;