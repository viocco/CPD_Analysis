-- Question 2: What are the frequencies of mismatches in TRR and complaint report filings? --
--  2.1) What are the categories for which an officer filed a TRR? What are the counts and percentages (as a percentage of
--       total officers allegations with a matching TRR) for these TRR categories?
--  2.2) What number of allegations have a TRR filed? What percent of allegations have a TRR filed?
--  2.3) What percent of allegations are categorized as use of force?

-- Create a temporary table to store the unique categories, their counts, and their percentage of total TRRs (including ones with null category) --
DROP TABLE IF EXISTS tmp;
CREATE TEMPORARY TABLE IF NOT EXISTS tmp
AS (WITH tmp AS (SELECT *
                FROM trr_trr, data_allegation, data_officerallegation, data_allegationcategory
                WHERE trr_trr.crid IS NOT NULL AND trr_trr.crid = data_allegation.crid AND data_allegation.crid = data_officerallegation.allegation_id AND (data_officerallegation.allegation_category_id = data_allegationcategory.id))
    SELECT tmp.category, count(*), (count(*)*100.0)/((SELECT count(*) FROM tmp) + (SELECT count(*) FROM trr_trr, data_allegation, data_officerallegation WHERE trr_trr.crid IS NOT NULL AND trr_trr.crid = data_allegation.crid AND data_allegation.crid = data_officerallegation.allegation_id AND data_officerallegation.allegation_category_id IS NULL)) as percent
    FROM tmp
    GROUP BY tmp.category
    ORDER BY count DESC);

-- Create entry that adds null category to table --
INSERT INTO tmp (category, count, percent)
VALUES (NULL,
        (SELECT count(*) FROM trr_trr, data_allegation, data_officerallegation WHERE trr_trr.crid IS NOT NULL AND trr_trr.crid = data_allegation.crid AND data_allegation.crid = data_officerallegation.allegation_id AND data_officerallegation.allegation_category_id IS NULL),
        (100.0*(SELECT count(*) FROM trr_trr, data_allegation, data_officerallegation WHERE trr_trr.crid IS NOT NULL AND trr_trr.crid = data_allegation.crid AND data_allegation.crid = data_officerallegation.allegation_id AND data_officerallegation.allegation_category_id IS NULL)/((SELECT sum(count) FROM tmp) + (SELECT count(*) FROM trr_trr, data_allegation, data_officerallegation WHERE trr_trr.crid IS NOT NULL AND trr_trr.crid = data_allegation.crid AND data_allegation.crid = data_officerallegation.allegation_id AND data_officerallegation.allegation_category_id IS NULL))));

-- Sum the number of TRRs that have a crid
SELECT sum(tmp.count)
FROM tmp;

-- Display Table --
SELECT category, count, ROUND(percent,2)
FROM tmp
UNION;

SELECT category, count, ROUND(percent,2)
FROM tmp
UNION
SELECT data_allegationcategory.category, 0.0 as count, 0.0 as percent
FROM data_allegationcategory
LEFT JOIN tmp ON data_allegationcategory.category ILIKE tmp.category
WHERE tmp.category IS NULL
ORDER BY count DESC;

