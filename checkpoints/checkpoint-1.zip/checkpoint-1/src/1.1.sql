-- Question 1: Is there sufficient data to analyze the discrepancies in recommended and final outcomes and findings? --
--  1.1) What are the unique categories for a final finding? When grouped by final finding, what are the allegation counts?
--       When grouped by final finding, what is the percent of allegations in each category?
--  1.2) What are the unique categories for a final outcome? When grouped by final outcome, what are the allegation counts?
--       When grouped by final outcome, what is the percent of allegations in each category?
--  1.3) What are the unique categories for a recommended finding? When grouped by recommended finding, what are the allegation
--       counts? When grouped by recommended finding, what is the percent of allegations in each category?
--  1.4) What are the unique categories for a recommended outcome? When grouped by recommended outcome, what are the allegation
--       counts? When grouped by recommended outcome, what is the percent of allegations in each category?
--  1.5) When grouped by final finding, what is the percentage of each final outcome as a percent of the total
--       outcomes for that final finding? What are the counts?

SELECT DOA.final_finding, count(*), ROUND((100.0*count(*))/ (SELECT count(*) FROM data_officerallegation),2) as percent
FROM data_officerallegation AS DOA
GROUP BY DOA.final_finding
ORDER BY count DESC;