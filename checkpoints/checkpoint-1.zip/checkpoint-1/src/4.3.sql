-- Question 4:  Is there a correlation between the race of the victim and the rate at which the recommended finding and outcome are finalized?  --
--  1) When grouped by the race of the victim, what is the distribution of recommended findings as counts and percentages of the
--     race's total allegations?
--  2) When grouped by the race of the victim, what is the distribution of final findings as counts and percentages of the race's
--     total allegations?
--  3) When grouped by the race of the victim, what is the distribution of recommended outcomes as counts and percentages of the
--     race's total allegations?
--  4) When grouped by the race of the victim, what is the distribution of final outcomes as counts and percentages of the race's
--     total allegations?
--  5) When grouped by race of victim, what percent of complaints in each race have a more/less severe recommended finding than
--     final finding (as a percent of? What percent of complaints in each allegation category have recommended findings or final findings that are null/unknown?
--  6) When grouped by race of victim, what percent of complaints in each race have a more/less severe recommended outcome than
--     final outcome?  What percent of complaints in each allegation category have recommended outcomes or final outcomes are
--     null/unknown?


-- Creating a temporary table with the counts of all the suspended summed together --
DROP TABLE IF EXISTS cleaned_DOA_recc;
CREATE TEMPORARY TABLE cleaned_DOA_recc AS (SELECT * FROM data_officerallegation);
UPDATE cleaned_DOA_recc SET recc_outcome='Suspended' WHERE recc_outcome ILIKE '%Suspen%';

SELECT tem.recc_outcome           as recc_outcome,
       tem.race                   as race,
       ROUND((100.0 * tem.N) / total.N,2) as Pct,
       tem.N                      as count
FROM ( SELECT race, recc_outcome, count(*) as N
       FROM data_victim as DV, data_allegation as DA, cleaned_DOA_recc as DOA
       WHERE DV.allegation_id = DA.crid AND DA.crid = DOA.allegation_id
       GROUP BY DV.race, DOA.recc_outcome
     ) tem
JOIN ( SELECT race , count(*) as N
       FROM data_victim as DV, data_allegation as DA, cleaned_DOA_recc as DOA
       WHERE DV.allegation_id = DA.crid AND DA.crid = DOA.allegation_id
       GROUP BY race
     ) total ON tem.race = total.race
ORDER BY tem.recc_outcome, Pct DESC;