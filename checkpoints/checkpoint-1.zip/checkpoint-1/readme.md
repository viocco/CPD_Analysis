# Checkpoint 1: SQL Analytics

## How to Run the Queries

The following instructions are relevant only to DataGrip. In order to run these queries in DataGrip, you'll first need to make sure you have an active connection to the `cpdb` database, either remote or local. For this, you can follow the instructions posted on Piazza. With that in place, simply open the `.sql` files in the `/src` directory and hit run. Alternatively, you can copy and paste the queries from the file into the DataGrip console and run them there.

## Questions 

Question 1: What are the frequencies of recommended and final outcomes and findings?
 1) What are the unique categories for a final finding? When grouped by final finding, what are the officer allegation counts? When grouped by final finding, what is the percent of officer allegations in each category?
 2) What are the unique categories for a final outcome? When grouped by final outcome, what are the officer allegation counts? When grouped by final outcome, what is the percent of officer allegations in each category?
 3) What are the unique categories for a recommended finding? When grouped by recommended finding, what are the officer allegation counts? When grouped by recommended finding, what is the percent of officer allegations in each category?
 4) What are the unique categories for a recommended outcome? When grouped by recommended outcome, what are the officer allegation counts? When grouped by recommended outcome, what is the percent of officer allegations in each category?
 5) When grouped by final finding, what is the percentage of each final outcome as a percent of the total outcomes for that final finding? What are the counts? 

Question 2: What are the frequencies of mismatches in TRR and complaint report filings?
 1) What are the categories for which an officer filed a TRR? What are the counts and percentages (as a percentage of total officers allegations with a matching TRR) for these TRR categories?
 2) How many instances are there when an allegation for force/excessive force is filed by a civilian and there is a Tactical Response Report (TRR) filed by the officer? What is this as a percentage of allegations of force/excessive force?

Question 3: Are certain groups of categories more likely to result in a less/more severe final findings or outcome than recommended for officers?
 1)When grouped by allegation category, what percent of complaints in each allegation category have a less/more severe recommended finding than final finding (as a percent of? What percent of complaints in each allegation category have recommended findings or final  findings that are null/unknown?
 2) When grouped by allegation category, what percent of complaints in each allegation category have a less/more severe recommended outcome than final outcome?  What percent of complaints in each allegation category have recommended outcomes or final outcomes are null/unknown?

Question 4:  Is there a correlation between the race of the victim and the rate at which the recommended finding and outcome are finalized? 
 1) When grouped by the race of the victim, what is the distribution of recommended findings as counts and percentages of the race's total allegations? 
 2) When grouped by the race of the victim, what is the distribution of final findings as counts and percentages of the race's total allegations? 
 3) When grouped by the race of the victim, what is the distribution of recommended outcomes as counts and percentages of the race's total allegations? 
 4) When grouped by the race of the victim, what is the distribution of final outcomes as counts and percentages of the race's total allegations? 
 5) When grouped by race of victim, what percent of complaints in each race have a less/more severe recommended finding than final finding (as a percent of? What percent of complaints in each allegation category have recommended findings or final findings that are null/unknown?
 6) When grouped by race of victim, what percent of complaints in each race have a less/more severe recommended outcome than final outcome?  What percent of complaints in each allegation category have recommended outcomes or final outcomes are null/unknown?

