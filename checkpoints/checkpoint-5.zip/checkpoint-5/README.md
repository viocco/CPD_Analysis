
# Checkpoint 5 #

This checkpoint uses NLP to answer the following question:

      1) Use sentiment analysis on the summaries of an allegation to determine if there is some explanation for the large 
         number of recommended findings that are null?

In order to run this checkpoint, have pip, python, and jupyter-lab installed. Then, run the ipynb file in src/

