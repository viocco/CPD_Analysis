
# Checkpoint 2

In order to view the visualizations in this Checkpoint, follow these steps:

    1) Download Tableau
    2) Ensure that you are connected to the remote version of the Northwestern-hosted CPDB.
    3) Click through the visualizations (each labeled for the question they answer)

Please note that these visualizations were created using temporary tables and custom sql quieries. Please
see src/intial_sql.sql for the intial_sql code and please see src/{1.1,1.2,1.3,1.4,2.1,2.2,2.3,2.4} for the custom SQL queries.

List of Questions:

    1) Do discrepancies between the final findings and recommended findings reveal any racial bias? Are there any trends between severity, race, and category of the allegation?
        1. A set of pie charts (one for each race) detailing final findings
        2. A set of pie charts (one for each race) detailing recommended findings
        3. Stacked bar graph (one for each category of an allegation against an officer) where there is a bar for each race that represents the ratio of final findings that are more severe than recommended findings to final findings that are less severe than recommended findings.
        4. Stacked categorical line graphs (one for each category) where each point on the x-axis is a race and the y-axis is the percent of allegations sustained for that category.
    2) Do discrepancies between the final outcomes and recommended outcomes reveal any racial bias? Are there any trends between severity, race, and category of the allegation?
        1. A set of pie charts (one for each race) detailing recommended outcomes
        2. A set of pie charts (one for each race) detailing final outcomes
        3. A stacked bar graph (one for each category of an allegation against an officer) where there is a bar for each race that represents the ratio of final findings that are more severe than recommended outcomes to final outcomes that are less severe than recommended findings.
        4. Stacked categorical line graphs (one for each category) where each point on the x-axis is a race and the y-axis is the average severity [0,61] (61 being most severe, 1 being least severe, 0 being null) of the final outcome for that category.


