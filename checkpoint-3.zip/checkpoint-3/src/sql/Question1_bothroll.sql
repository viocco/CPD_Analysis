DROP TABLE IF EXISTS cleaned_DOA_fin;
CREATE TEMPORARY TABLE cleaned_DOA_fin AS (SELECT * FROM data_officerallegation);
DELETE FROM cleaned_DOA_fin WHERE cleaned_DOA_fin.final_finding ILIKE 'NC' OR cleaned_DOA_fin.final_finding ILIKE 'DS' OR cleaned_DOA_fin.final_finding ILIKE 'ZZ';
ALTER TABLE cleaned_DOA_fin ALTER COLUMN final_finding TYPE VARCHAR (32);
UPDATE cleaned_DOA_fin SET final_finding='Unspecified' WHERE final_finding ILIKE '';

DROP TABLE IF EXISTS cleaned_DV_fin;
CREATE TEMPORARY TABLE cleaned_DV_fin AS (SELECT * FROM data_victim);
UPDATE cleaned_DV_fin SET race='Unspecified' WHERE race ILIKE '';

WITH total_count AS (SELECT CASE
                         WHEN CAST(name AS INT) BETWEEN 100 AND 199 THEN '1ST'
                         WHEN CAST(name AS INT) BETWEEN 200 AND 299 THEN '2ND'
                         WHEN CAST(name AS INT) BETWEEN 300 AND 399 THEN '3RD'
                         WHEN CAST(name AS INT) BETWEEN 400 AND 499 THEN '4TH'
                         WHEN CAST(name AS INT) BETWEEN 500 AND 599 THEN '5TH'
                         WHEN CAST(name AS INT) BETWEEN 600 AND 699 THEN '6TH'
                         WHEN CAST(name AS INT) BETWEEN 700 AND 799 THEN '7TH'
                         WHEN CAST(name AS INT) BETWEEN 800 AND 899 THEN '8TH'
                         WHEN CAST(name AS INT) BETWEEN 900 AND 999 THEN '9TH'
                         WHEN CAST(name AS INT) BETWEEN 1000 AND 1099 THEN '10TH'
                         WHEN CAST(name AS INT) BETWEEN 1100 AND 1199 THEN '11TH'
                         WHEN CAST(name AS INT) BETWEEN 1200 AND 1399 THEN '12TH'
                         WHEN CAST(name AS INT) BETWEEN 1400 AND 1499 THEN '14TH'
                         WHEN CAST(name AS INT) BETWEEN 1500 AND 1599 THEN '15TH'
                         WHEN CAST(name AS INT) BETWEEN 1600 AND 1699 THEN '16TH'
                         WHEN CAST(name AS INT) BETWEEN 1700 AND 1799 THEN '17TH'
                         WHEN CAST(name AS INT) BETWEEN 1800 AND 1899 THEN '18TH'
                         WHEN CAST(name AS INT) BETWEEN 1900 AND 1999 THEN '19TH'
                         WHEN CAST(name AS INT) BETWEEN 2000 AND 2099 THEN '20TH'
                         WHEN CAST(name AS INT) BETWEEN 2200 AND 2299 THEN '22ND'
                         WHEN CAST(name AS INT) BETWEEN 2400 AND 2499 THEN '24TH'
                         WHEN CAST(name AS INT) BETWEEN 2500 AND 2599 THEN '25TH'
                         WHEN CAST(name AS INT) BETWEEN 3100 AND 3199 THEN '31ST'
                         END AS district_name,
                       count(*) as total_count
                FROM (SELECT *
                           FROM cleaned_DV_fin AS DV
                           JOIN (SELECT *
                                      FROM cleaned_DOA_fin as DOA, data_allegation as DA, data_area
                                      WHERE DOA.allegation_id = DA.crid AND data_area.id = DA.beat_id) AS unique_allegations
                           ON DV.allegation_id = unique_allegations.allegation_id) AS unique_allegations
                GROUP BY district_name
                ORDER BY district_name),
     partial_counts AS (SELECT CASE
                             WHEN CAST(name AS INT) BETWEEN 100 AND 199 THEN '1ST'
                             WHEN CAST(name AS INT) BETWEEN 200 AND 299 THEN '2ND'
                             WHEN CAST(name AS INT) BETWEEN 300 AND 399 THEN '3RD'
                             WHEN CAST(name AS INT) BETWEEN 400 AND 499 THEN '4TH'
                             WHEN CAST(name AS INT) BETWEEN 500 AND 599 THEN '5TH'
                             WHEN CAST(name AS INT) BETWEEN 600 AND 699 THEN '6TH'
                             WHEN CAST(name AS INT) BETWEEN 700 AND 799 THEN '7TH'
                             WHEN CAST(name AS INT) BETWEEN 800 AND 899 THEN '8TH'
                             WHEN CAST(name AS INT) BETWEEN 900 AND 999 THEN '9TH'
                             WHEN CAST(name AS INT) BETWEEN 1000 AND 1099 THEN '10TH'
                             WHEN CAST(name AS INT) BETWEEN 1100 AND 1199 THEN '11TH'
                             WHEN CAST(name AS INT) BETWEEN 1200 AND 1399 THEN '12TH'
                             WHEN CAST(name AS INT) BETWEEN 1400 AND 1499 THEN '14TH'
                             WHEN CAST(name AS INT) BETWEEN 1500 AND 1599 THEN '15TH'
                             WHEN CAST(name AS INT) BETWEEN 1600 AND 1699 THEN '16TH'
                             WHEN CAST(name AS INT) BETWEEN 1700 AND 1799 THEN '17TH'
                             WHEN CAST(name AS INT) BETWEEN 1800 AND 1899 THEN '18TH'
                             WHEN CAST(name AS INT) BETWEEN 1900 AND 1999 THEN '19TH'
                             WHEN CAST(name AS INT) BETWEEN 2000 AND 2099 THEN '20TH'
                             WHEN CAST(name AS INT) BETWEEN 2200 AND 2299 THEN '22ND'
                             WHEN CAST(name AS INT) BETWEEN 2400 AND 2499 THEN '24TH'
                             WHEN CAST(name AS INT) BETWEEN 2500 AND 2599 THEN '25TH'
                             WHEN CAST(name AS INT) BETWEEN 3100 AND 3199 THEN '31ST'
                             END AS district_name,
                        count(*) as partial_count
                    FROM (SELECT *
                               FROM cleaned_DV_fin AS DV
                               JOIN (SELECT *
                                          FROM cleaned_DOA_fin as DOA, data_allegation as DA, data_area
                                          WHERE DOA.allegation_id = DA.crid AND data_area.id = DA.beat_id) AS unique_allegations
                               ON DV.allegation_id = unique_allegations.allegation_id) AS unique_allegations
                    WHERE final_finding = recc_finding
                    GROUP BY district_name
                    ORDER BY district_name),
     partial_unrepresented as (SELECT *,0 as partial_count FROM ((SELECT district_name FROM total_count) EXCEPT (SELECT district_name FROM partial_counts)) as t1),
     unrepresented_total as (SELECT *
                        FROM (SELECT DISTINCT district_name
                              FROM (SELECT CASE
                                             WHEN CAST(name AS INT) BETWEEN 100 AND 199 THEN '1ST'
                                             WHEN CAST(name AS INT) BETWEEN 200 AND 299 THEN '2ND'
                                             WHEN CAST(name AS INT) BETWEEN 300 AND 399 THEN '3RD'
                                             WHEN CAST(name AS INT) BETWEEN 400 AND 499 THEN '4TH'
                                             WHEN CAST(name AS INT) BETWEEN 500 AND 599 THEN '5TH'
                                             WHEN CAST(name AS INT) BETWEEN 600 AND 699 THEN '6TH'
                                             WHEN CAST(name AS INT) BETWEEN 700 AND 799 THEN '7TH'
                                             WHEN CAST(name AS INT) BETWEEN 800 AND 899 THEN '8TH'
                                             WHEN CAST(name AS INT) BETWEEN 900 AND 999 THEN '9TH'
                                             WHEN CAST(name AS INT) BETWEEN 1000 AND 1099 THEN '10TH'
                                             WHEN CAST(name AS INT) BETWEEN 1100 AND 1199 THEN '11TH'
                                             WHEN CAST(name AS INT) BETWEEN 1200 AND 1399 THEN '12TH'
                                             WHEN CAST(name AS INT) BETWEEN 1400 AND 1499 THEN '14TH'
                                             WHEN CAST(name AS INT) BETWEEN 1500 AND 1599 THEN '15TH'
                                             WHEN CAST(name AS INT) BETWEEN 1600 AND 1699 THEN '16TH'
                                             WHEN CAST(name AS INT) BETWEEN 1700 AND 1799 THEN '17TH'
                                             WHEN CAST(name AS INT) BETWEEN 1800 AND 1899 THEN '18TH'
                                             WHEN CAST(name AS INT) BETWEEN 1900 AND 1999 THEN '19TH'
                                             WHEN CAST(name AS INT) BETWEEN 2000 AND 2099 THEN '20TH'
                                             WHEN CAST(name AS INT) BETWEEN 2200 AND 2299 THEN '22ND'
                                             WHEN CAST(name AS INT) BETWEEN 2400 AND 2499 THEN '24TH'
                                             WHEN CAST(name AS INT) BETWEEN 2500 AND 2599 THEN '25TH'
                                             WHEN CAST(name AS INT) BETWEEN 3100 AND 3199 THEN '31ST'
                                     END AS district_name,
                                    count(*) as partial_count
                                     FROM (SELECT *
                                           FROM cleaned_DV_fin AS DV
                                           JOIN (SELECT *
                                                  FROM cleaned_DOA_fin as DOA, data_allegation as DA, data_area
                                                  WHERE DOA.allegation_id = DA.crid AND data_area.id = DA.beat_id) AS unique_allegations
                                       ON DV.allegation_id = unique_allegations.allegation_id) AS unique_allegations
                            WHERE final_finding = recc_finding
                            GROUP BY district_name
                            ORDER BY district_name) as t1) as t2
                        EXCEPT
                        SELECT district_name FROM total_count)
SELECT PC.district_name, PC.partial_count, CASE WHEN TC.total_count IS NULL THEN 0 ELSE TC.total_count END as total_count, ROUND(PC.partial_count*1.0/TC.total_count*1.0,2) as pct
FROM total_count AS TC
RIGHT JOIN (SELECT district_name, partial_count FROM partial_counts UNION SELECT district_name, partial_count FROM partial_unrepresented) as PC
ON TC.district_name LIKE PC.district_name
UNION
SELECT *,0,0,0 FROM unrepresented_total
ORDER BY partial_count DESC;
