SELECT race, t1.partial as yes, t1.total - t1.partial as no
FROM
(WITH partial as (SELECT race, count(*) as partial
                FROM (SELECT *
                      FROM data_allegation DA,data_officerallegation DOA, data_allegationcategory DAC, cleaned_DV_fin DV
                      WHERE DV.allegation_id = DA.crid AND DA.crid = DOA.allegation_id AND DOA.allegation_category_id = DAC.id AND (DAC.category ILIKE '%Force%') AND DATE(DA.incident_date) >= '01/01/2004' AND DATE(DA.incident_date) < '01/01/2016') as tmp, trr_trr
                WHERE tmp.crid = trr_trr.crid
                GROUP BY race),
     total as (SELECT race, count(*) as total
                FROM (SELECT *
                      FROM data_allegation DA,data_officerallegation DOA, data_allegationcategory DAC, cleaned_DV_fin DV
                      WHERE DV.allegation_id = DA.crid AND DA.crid = DOA.allegation_id AND DOA.allegation_category_id = DAC.id AND (DAC.category ILIKE '%Force%') AND DATE(DA.incident_date) >= '01/01/2004' AND DATE(DA.incident_date) < '01/01/2016') as tmp
                GROUP BY race),
    not_in_partial as ((SELECT total.race FROM total) EXCEPT (SELECT race FROM partial))
SELECT partial.race, partial, total, 100.0*ROUND(partial*1.0/total,2) as percent
FROM total, partial
WHERE total.race = partial.race
UNION
(SELECT *,0,29,0 FROM not_in_partial)) t1;