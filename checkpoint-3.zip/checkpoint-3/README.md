
# Checkpoint #3

In this checkpoint, we created several interactive graphics from the data.
In order to find these graphics, please go to src/graphics/Question<#>.txt and click on the link in this file.

Questions:
    
    1) Do discrepancies between the final findings and recommended findings reveal any community bias? Are there any trends between severity, community, and category of the allegation? 
       A choropleth of the city of Chicago broken down into beats with each beat being colored according to the percentage of officer allegations with equal recommended and final finding. 
       The interactive element is the selection of the race of the victim.
    2) Do discrepancies between the final outcomes and recommended outcomes reveal any community bias? Are there any trends between severity, community, beat and category of the allegation?
       A choropleth of the city of Chicago broken down into beats with each beat being colored according to the percentage of officer allegations with equal recommended and final outcomes. 
       The interactive element is the selection of the race of the victim and the category of allegation.
    3) Is there a correlation between the race of the victim and whether or not officers decide to write TRRs?
       A pie chart that shows the percent of that race’s use of force allegations for which there is a TRR. Add 
       an interactive element to switch between race of victim.